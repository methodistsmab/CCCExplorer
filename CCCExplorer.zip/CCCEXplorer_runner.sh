#!/bin/bash
java -jar CCCExplorer.jar