
args<-commandArgs(trailingOnly=TRUE)

print (args)
print ("------------------------")

dir<-args[1]
source_exprs<-args[2]
target_exprs<-args[3]
Fold_thres_S<-as.single(args[4])
q_thres_S<-as.single(args[5])
FPKM_thres_S<-as.single(args[6])
Fold_thres_T<-as.single(args[7])
q_thres_T<-as.single(args[8])
FPKM_thres_T<-as.single(args[9])

load("CCCExplorer.rda")
CCCExplorer(dir,source_exprs,target_exprs,Fold_thres_S,q_thres_S,FPKM_thres_S,Fold_thres_T,q_thres_T,FPKM_thres_T)
