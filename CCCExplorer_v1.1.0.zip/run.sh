java -jar CCCExplorer.jar
