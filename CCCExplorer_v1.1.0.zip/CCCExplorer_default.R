
args<-commandArgs(trailingOnly=TRUE)

print (args)
print ("------------------------")

dir<-args[1]
reportfile<-args[2]
source_exprs<-args[3]
target_exprs<-args[4]
Fold_thres_S<-as.single(args[5])
q_thres_S<-as.single(args[6])
FPKM_thres_S<-as.single(args[7])
Fold_thres_T<-as.single(args[8])
q_thres_T<-as.single(args[9])
FPKM_thres_T<-as.single(args[10])

load("CCCExplorer.rda")
CCCExplorer(dir,reportfile, source_exprs,target_exprs,Fold_thres_S,q_thres_S,FPKM_thres_S,Fold_thres_T,q_thres_T,FPKM_thres_T)
